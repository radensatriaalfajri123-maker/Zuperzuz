# Dunia Tanpa Batas 3D (Android)
Cara dapat APK:
1. Upload folder ini ke repo GitHub baru (branch main).
2. Buka tab Actions > Build APK > tunggu hijau.
3. Unduh artifact "dunia-tanpa-batas-apk" > app-debug.apk, lalu install di HP.
Atau buka folder ini di Android Studio > Build > Build APK(s).
Game ada di app/src/main/assets/index.html (offline, three.js sudah ikut).
